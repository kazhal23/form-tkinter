import os
import tkinter as tk
from tkinter import LabelFrame, ttk , messagebox 
import csv

def enter_data():
    accepted = accept_var.get()
    if accepted == "Accepted":
        firstname = first_name_entry.get()
        lastname = last_name_entry.get()
        title = title_combobox.get()
        age = age_spinbox.get()
        nationality = nationality_combobox.get()
        num_courses = num_courses_spinbox.get()
        num_semester = num_semester_spinbox.get()
        Registeration_Staus = reg_status_var.get()

        print("Firstname:", firstname, "Lastname:", lastname)
        print("Nationality:", nationality, "age:", age, "title:", title)
        print("numcourses:", num_courses, "numsemester:", num_semester)
        print("Registeration Staus", Registeration_Staus)
        print("...........................................................")

        script_dir = os.path.dirname(os.path.abspath(__file__))
        file_path = os.path.join(script_dir, "user_data.csv")
        with open(file_path, "a", newline="") as csvfile:
            writer = csv.writer(csvfile)
            writer.writerow([firstname, lastname, title, age, nationality, num_courses, num_semester])
    else:
        messagebox.showwarning(title="Error", message="You have not accepted the terms")

def add_padding(frame):
    for widget in frame.winfo_children():
        widget.grid_configure(padx=10, pady=5)

window = tk.Tk()
window.title("sign in")
frame = tk.Frame(window)
frame.pack()


user_info_frame = LabelFrame(frame, text="User Information")
user_info_frame.grid(row=0, column=0)
first_name_label = tk.Label(user_info_frame, text="First name")
first_name_label.grid(row=0, column=0)
last_name_label = tk.Label(user_info_frame, text="Last name")
last_name_label.grid(row=0, column=1)
first_name_entry = tk.Entry(user_info_frame)
last_name_entry = tk.Entry(user_info_frame)
first_name_entry.grid(row=1, column=0)
last_name_entry.grid(row=1, column=1)

title_label = ttk.Label(user_info_frame, text="Title")
title_label.grid(row=0, column=2)
title_combobox = ttk.Combobox(user_info_frame, values=["Mr.", "Ms.", "Dr.", "Prof."])
title_combobox.grid(row=1, column=2)

age_lebel = tk.Label(user_info_frame, text="Age")
age_spinbox = tk.Spinbox(user_info_frame, from_=18, to=118)
age_lebel.grid(row=2, column=0)
age_spinbox.grid(row=3, column=0)

nationality_label = tk.Label(user_info_frame, text="Nationality")
nationality_combobox = ttk.Combobox(user_info_frame, values=["Asia", "Africa", "Europe", "North America", "South America", "Atlantis", "South Pole",
                                                          "North Pole", "Oceania", "Atlantis", "Australia"])
nationality_label.grid(row=2, column=1)
nationality_combobox.grid(row=3, column=1)

add_padding(user_info_frame)


courses_frame = tk.LabelFrame(frame)
courses_frame.grid(row=1, column=0, sticky="news", padx=20, pady=20)

registered_label = tk.Label(courses_frame, text="Registeration Staus")
reg_status_var = tk.StringVar(value="Not Registered")
registered_check = tk.Checkbutton(courses_frame, text="Currently Registered", variable=reg_status_var, onvalue="Registered", offvalue="Not Registered")
registered_label.grid(row=0, column=0)
registered_check.grid(row=1, column=0)

num_courses_label = tk.Label(courses_frame, text="# Completed Courses")
num_courses_spinbox = tk.Spinbox(courses_frame, from_=0, to='infinity')
num_courses_label.grid(row=0, column=2)
num_courses_spinbox.grid(row=1, column=2)

num_semester_label = tk.Label(courses_frame, text="# Semester")
num_semester_spinbox = tk.Spinbox(courses_frame, from_=0, to='infinity')
num_semester_label.grid(row=4, column=2)
num_semester_spinbox.grid(row=3, column=2)

add_padding(courses_frame)

terms_frame = tk.LabelFrame(frame, text="Terms & Condition")
terms_frame.grid(row=2, column=0, sticky="news", padx=20, pady=10)

accept_var = tk.StringVar(value="Not Accepted")
terms_check = tk.Checkbutton(terms_frame, text="I accept the terms and condition", variable=accept_var, onvalue="Accepted", offvalue="Not Accepted")
terms_check.grid(row=0, column=0)


button = tk.Button(frame, text="Enter", command=enter_data)
button.grid(row=3, column=0, sticky="news", padx=20, pady=10)

window.mainloop()
